import socket
import threading
import json
from chain import Blockchain
from block import Block

PORT = 6060
PEERS = []  # Add IPs like ["192.168.1.5"]

bc = Blockchain()

def handle(conn):
    try:
        data = json.loads(conn.recv(10_000_000).decode())
        incoming_chain = [Block(**b) for b in data["chain"]]
        if len(incoming_chain) > len(bc.chain):
            bc.chain = incoming_chain
            bc.balances = data["balances"]
            bc.supply = data["supply"]
            bc.last_time = data.get("last_time",0)
            bc.save_chain()
    except Exception as e:
        print("Error handling peer:", e)
    finally:
        conn.close()

def listen():
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.bind(("",PORT))
    s.listen()
    print(f"Node listening on port {PORT}")
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle,args=(conn,),daemon=True).start()

def broadcast():
    msg = json.dumps({
        "chain":[b.__dict__ for b in bc.chain],
        "balances": bc.balances,
        "supply": bc.supply,
        "last_time": bc.last_time
    }).encode()
    for p in PEERS:
        try:
            s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            s.connect((p,PORT))
            s.sendall(msg)
            s.close()
        except:
            pass

threading.Thread(target=listen,daemon=True).start()
