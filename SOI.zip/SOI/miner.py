from wallet import create_wallet, create_tx
from chain import Blockchain
from node import broadcast, PEERS

bc = Blockchain()
wallet = create_wallet()
address = wallet["address"]
stats = {"completed":0,"failed":0}

print("SOI address:", address)
print("Private key:", wallet["private_key"])
print("Public key:", wallet["public_key"])

# Example: auto-send every 5 blocks
friend_address = "PLACEHOLDER_FRIEND_ADDRESS"
tx_pool = []
send_interval = 5
block_count = 0

while True:
    # Add txs to block
    block = bc.add_block(address, tx_pool, stats)
    tx_pool = []
    block_count += 1

    # Auto-send example
    if block_count % send_interval == 0:
        tx = create_tx(wallet, friend_address, 0.01)
        tx_pool.append(tx)

    if block:
        print("⛏ Block mined:", block.height)
        print("Hash:", block.hash)
        print("Completed hashes:", stats["completed"])
        print("Failed hashes:", stats["failed"])
        print("Supply:", round(bc.supply,6))
        print("Difficulty:", bc.difficulty)
        print("-"*40)

    # Broadcast chain
    broadcast()
